package com.lagou.filter;

import org.apache.dubbo.common.constants.CommonConstants;
import org.apache.dubbo.common.extension.Activate;
import org.apache.dubbo.rpc.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.*;

@Activate(group = {CommonConstants.PROVIDER})
public class TPMonitorFilter implements Runnable, Filter {
    private  static  final Logger  LOGGER = LoggerFactory.getLogger(TPMonitorFilter.class);

    private  Map<String, List<Long>>   timeCache = new ConcurrentHashMap<>();

    public  TPMonitorFilter(){
        // 每隔3秒打印线程使用情况
        Executors.newSingleThreadScheduledExecutor().scheduleWithFixedDelay(this,1,5, TimeUnit.SECONDS);
    }

    @Override
    public void run() {
        for (Map.Entry<String,List<Long>> entry : timeCache.entrySet()){
            String key = entry.getKey();
            List<Long> timeValues = entry.getValue();
            Collections.sort(timeValues);

            int index1 = new Double(Math.ceil(timeValues.size() * 0.9)).intValue();
            int index2 = new Double(Math.ceil(timeValues.size() * 0.99)).intValue();

            System.out.println(key+"总的调用次数："+timeValues.size()+"---------tp90:"+index1+":"+timeValues.get(index1)+"--------top99:"+index2+":"+timeValues.get(index2));
        }
        timeCache = new ConcurrentHashMap<>();
    }

    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
               long startTime = System.currentTimeMillis();

        Result result = invoker.invoke(invocation);

        String key = invocation.getMethodName();
        if(!timeCache.containsKey(key)){
            timeCache.put(key,new CopyOnWriteArrayList<>());
        }

        long endTime = System.currentTimeMillis();
        timeCache.get(key).add(endTime - startTime);

        return result;
    }
}
