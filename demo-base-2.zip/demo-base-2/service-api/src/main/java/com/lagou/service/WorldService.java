package com.lagou.service;

public interface WorldService {
    String  helloWorld(String name);
}
