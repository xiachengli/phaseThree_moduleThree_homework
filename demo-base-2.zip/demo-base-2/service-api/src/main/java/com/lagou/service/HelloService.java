package com.lagou.service;

public interface HelloService {
    String  sayHello(String name);

    String methodA();

    String methodB();

    String methodC();
}
